def dfs(cnt, tmp, prev):
    global ans
    # 가지치기
    if tmp >= ans:  # 현재까지 더한 값이 ans보다 크거나 같으면 더이상 계산할 필요가 없음
        return
    # 종료조건
    if cnt == N-1:  # 끝까지 다 돌았을 경우
        tmp += arr[prev][0]     # 마지막 위치에서 사무국으로 가는 배터리 소비량을 더함
        ans = min(ans, tmp)     # 현재까지 계산한 값과 ans에 저장된 값 중 최솟값 반환
        return
    # 하부조건
    if prev == b and used[a] == 0:    # b를 먼저 들렀는데 a가 먼저 들러지지 않은 경우 불가능
        return
    else:
        for i in range(1, N):
            if used[i] == 0:    # 아직 지나가지 않은 지점
                used[i] = 1
                dfs(cnt+1, tmp + arr[prev][i], i)
                # 횟수 +1, 배터리 소비량 더해주고, 현재 값을 이전 값으로 저장해 반환
                used[i] = 0

T = int(input())
for tc in range(1, T+1):
    N = int(input())
    arr = [list(map(int, input().split())) for _ in range(N)]
    a, b = map(int, input().split())
    used = [0] * N  # 앞에서 지나갔는지 여부
    used[0] = 1
    ans = 1000
    dfs(0, 0, 0)
    print(f'#{tc} {ans}')