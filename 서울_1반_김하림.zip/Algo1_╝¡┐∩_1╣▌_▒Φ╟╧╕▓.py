T = int(input())
for tc in range(1, T+1):
    N = int(input())
    hex = input()
    # h에 2진수로 바꾼 값을 저장
    h = ''
    for c in hex:
        if c.isdigit(): # 숫자일 경우
            tmp = int(bin(int(c)), 2)   # 그대로 2진수로 변환 후 정수값 저장
        else:   # 문자일 경우
            tmp = ord(c) - ord('A') + 10    # 아스키코드 값을 이용해 정수값을 저장
        tmp2 = str(bin(tmp)).lstrip('0b')   # 정수값을 2진수로 변환함
        if len(tmp2) < 4:   # 변환한 길이가 4보다 작을 경우
            tmp2 = tmp2.zfill(4)    # 길이가 4가 되도록 앞을 0으로 채워줌
        h += tmp2   # h에 계속 더해감

    cnt, ans = 0, 0
    for c in h:     # 각 자리에 대해서
        if c == '1':    # 1이면 cnt를 늘리고
            cnt += 1
        if c == '0':    # 0을 만나면 현재까지의 값과 ans 중 큰 값을 갱신
            ans = max(ans, cnt)
            cnt = 0     # 다시 cnt를 0으로 돌림
    ans = max(ans, cnt) # 끝까지 0을 못 만났을 경우 큰 값으로 한 번 더 갱신
    print(f'#{tc} {ans}')